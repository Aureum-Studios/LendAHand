import java.awt.Graphics;

public class WithVikingHat extends SpriteDecorator {

	private int sizeOffset;
	private int xOffset;
	private int yOffset;
	
	public WithVikingHat(Sprite s, int xOffset, int yOffset, int sizeOffset) {
		super(s, Settings.VIKING_HAT_IMAGE);
		this.sizeOffset = sizeOffset;
		this.xOffset = xOffset;
		this.yOffset = yOffset;
	}

	@Override
	public void update(Graphics g){
		super.update(g);
		
		// Position hat
		int hatSize = decoratedSprite.getSize() + sizeOffset;
		int hatX = decoratedSprite.getX()  + xOffset;
		int hatY = decoratedSprite.getY()  + yOffset;
		
		g.drawImage(image, hatX, hatY, hatSize, hatSize, null);
	}
	
}
