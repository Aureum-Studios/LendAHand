import java.util.List;

public class ListSpriteFactory implements SpriteFactory {
	
	private List<Sprite> spriteList;
	private int generated = 0;
	
	ListSpriteFactory(List<Sprite> spriteList) {
		this.spriteList = spriteList;
	}
	
	@Override
	public Sprite spawnNext() {
		
		// set up board initially
		if (hasNext()) {
			return spriteList.get(generated++);
		}
		return null;
	}

	@Override
	public boolean hasNext() {
		return generated != spriteList.size();
	}

}
