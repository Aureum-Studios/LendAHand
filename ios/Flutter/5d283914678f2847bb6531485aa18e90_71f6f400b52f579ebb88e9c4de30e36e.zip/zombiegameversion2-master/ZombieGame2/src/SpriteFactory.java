
public interface SpriteFactory {
	
	public Sprite spawnNext();
	public boolean hasNext();
	
}
