import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class SpriteDecorator extends Sprite {

	protected final Sprite decoratedSprite;
	protected Image image;
	
	public SpriteDecorator(Sprite s, String imagePath){
		super(s);
		decoratedSprite = s;
		try {
	    	image = ImageIO.read(new File(imagePath));
	    } catch (IOException ioe) {
	    	System.out.println("Unable to load image file.");
	    }
	}

	
	// This is the one method that we want to extend, so we do not make it final
	@Override
	public void update(Graphics g) { decoratedSprite.update(g); }
	
	// the following final methods have been defined to 
	// make sure that a decorated sprite behave the same as the sprite being decorated
	// compare these methods to those of a sprite
	@Override
    public final void updatePosition() { decoratedSprite.updatePosition(); }
	@Override
	public final void setDest(int x, int y) { decoratedSprite.setDest(x, y); }
	@Override
	public final void setPos(int x, int y) { decoratedSprite.setPos(x, y); }
	@Override
    public final int getX() {	return decoratedSprite.getX(); }
	@Override
    public final int getY() {	return decoratedSprite.getY(); }
	@Override
	public final int getSize() {	return decoratedSprite.getSize(); }
	@Override
	public final void setSize(int size)   { decoratedSprite.setSize(size);   }
	@Override
	public final void setMoveStrategy(MoveStrategy ms)   { decoratedSprite.setMoveStrategy(ms);   }

	
}
