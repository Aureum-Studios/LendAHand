import java.util.Random;

public class LevelOneSpriteFactory implements SpriteFactory {

	private int zRemaining;
	private int wRemaining;
	
	LevelOneSpriteFactory() {
		// the first level will have 2 zombies and 2 werewolves
		zRemaining = 2;
		wRemaining = 2;
	}
	
	@Override
	public Sprite spawnNext() {
		
		// set up board initially
		Random r = new Random();
		int x = r.nextInt(Settings.WIDTH);
		int y = r.nextInt(Settings.HEIGHT);
				
		if (zRemaining > 0)
		{
			zRemaining--;
			Sprite z = new Zombie(x, y);
			z.setMoveStrategy(new SlowDumbChase());
			return z;
		}
		if (wRemaining > 0)
		{
			wRemaining--;
			Sprite w = new Werewolf(x, y);
			w.setMoveStrategy(new SlowDumbChase());
			return w;
		}
		return null;
	}

	@Override
	public boolean hasNext() {
		return zRemaining + wRemaining != 0;
	}

}
