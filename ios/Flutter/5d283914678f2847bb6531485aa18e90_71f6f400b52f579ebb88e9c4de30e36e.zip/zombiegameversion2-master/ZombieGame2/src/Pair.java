
public class Pair {

	public int x;
	public int y;
	
}
